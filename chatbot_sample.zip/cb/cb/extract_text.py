import os
import PyPDF4
from sentence_transformers import SentenceTransformer
from chromadb import Client, Settings
import numpy as np

def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, "rb") as file:
        
        reader = PyPDF4.PdfFileReader(file)
        for page_num in range(reader.getNumPages()):
            page = reader.getPage(page_num)
            text += page.extractText()
    return text

# Initialize Chroma client and SentenceTransformer
chroma_client = Client(Settings())
model = SentenceTransformer('all-MiniLM-L6-v2')

# Create a collection in ChromaDB
faq_collection = chroma_client.create_collection("faq_data")

# Path to the folder containing PDFs
pdf_folder = r"C:\Users\Metaprime\Downloads\cb\pdfs"
output_file = "faq_texts.txt"

# Extract text from PDFs and generate embeddings
with open(output_file, "w", encoding="utf-8") as f:
    for idx, pdf_file in enumerate(os.listdir(pdf_folder)):
        if pdf_file.endswith(".pdf"):
            pdf_path = os.path.join(pdf_folder, pdf_file)
            faq_text = extract_text_from_pdf(pdf_path)
            f.write(faq_text + "\n")
            
            # Generate embeddings for the extracted text
            faq_embedding = model.encode(faq_text.strip())

            # Ensure embedding is in list format
            if isinstance(faq_embedding, np.ndarray):
                faq_embedding_list = faq_embedding.tolist()
            else:
                raise ValueError("Embedding should be a NumPy ndarray")

            # Add the text and its embedding to the collection
            doc_id = f"faq_{idx}"
            faq_collection.upsert(documents=[faq_text.strip()], ids=[doc_id], embeddings=[faq_embedding_list])

