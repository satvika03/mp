from flask import Flask, request, jsonify, render_template
from sentence_transformers import SentenceTransformer
from chromadb import Client, Settings
import openai
from langchain.memory import ConversationBufferMemory

app = Flask(__name__)

# Initialize Chroma client and SentenceTransformer
chroma_client = Client(Settings())
model = SentenceTransformer('all-MiniLM-L6-v2')

def load_faq_data(file_path):
    faq_data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read().strip()
        entries = content.split('\n\n')
        for entry in entries:
            if entry.startswith('Q:') and '\nA:' in entry:
                question, answer = entry.split('\nA:', 1)
                question = question.replace('Q:', '').strip()
                answer = answer.strip()
                faq_data.append({'question': question, 'answer': answer})
    return faq_data

faq_data = load_faq_data('faq_texts.txt')

# Check if the collection exists, if not create it
collection_name = "faq_data"
existing_collections = chroma_client.list_collections()
if collection_name not in [col.name for col in existing_collections]:
    faq_collection = chroma_client.create_collection(collection_name)
    for faq in faq_data:
        embedding = model.encode(faq['question']).tolist()  # Encode the question to get embedding
        faq_collection.add(faq['question'], metadatas=[{'answer': faq['answer']}], embeddings=[embedding])
else:
    faq_collection = chroma_client.get_collection(collection_name)

# Initialize OpenAI API
openai.api_key = "sk-xYCdlaH8sCxjkeykeygdrrutstydydufu"

# Initialize memory for maintaining chat history
memory = ConversationBufferMemory()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    user_embedding = model.encode(user_message).tolist()

    # Retrieve relevant FAQ entries
    search_results = faq_collection.query(user_embedding)

    top_answers = []
    if search_results is not None and search_results.get("metadatas") is not None:
        metadatas = search_results["metadatas"]  # Extract metadatas 
        distances = search_results["distances"]  # Extract distances
        # Combine metadata and distances into tuples for sorting
        combined_data = list(zip(metadatas, distances))
        # Flatten the list of metadatas and distances if necessary
        combined_data = [(metadata, distance) for sublist in combined_data for metadata, distance in zip(sublist[0], sublist[1])]
        # Sort combined data based on distances
        sorted_data = sorted(combined_data, key=lambda x: x[1])
        # Extract answers corresponding to the top 2 low distances
        for metadata, distance in sorted_data[:2]:
            top_answers.append(metadata["answer"])
        relevant_info = "\n".join(top_answers)

    # Prepare the combined input for the prompt
    history_text = ""
    if isinstance(memory.buffer, list):
        history_text = "\n".join([f"{msg.get('role', '')}: {msg.get('content', '')}" for msg in memory.buffer])

    combined_input = f"History:\n{history_text}\n\nFAQs:\n{relevant_info}\n\nUser's question: {user_message}\n\nBased only on the following information from the FAQs and previous conversation history, respond to the user's query in a concise way."

    # Generate a response using OpenAI API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": combined_input}
        ]
    )

    # Extract the text from the response object
    response_text = response['choices'][0]['message']['content'].strip()

    # Save the conversation to memory
    memory.save_context({"input": user_message}, {"output": response_text})

    return jsonify({'response': response_text})

if __name__ == '__main__':
    app.run(debug=True)

