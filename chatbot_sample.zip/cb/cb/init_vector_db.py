import chromadb
from chromadb.config import Settings
from langchain_openai import OpenAIEmbeddings
import openai
import os

# Initialize Chroma client
chroma_client = chromadb.Client(Settings())

# Initialize OpenAI embeddings
openai_api_key = "sk-proj-onryLkwrvicLf9kFOrYvT3BlbkFJWW97qA2l4BJ37vvT6K4X"
embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)

faq_collection = chroma_client.create_collection("faq_data")

# Read extracted FAQ texts from the file
faq_texts = []
with open("faq_texts.txt", "r", encoding="utf-8") as f:
    faq_texts = f.readlines()

# Add extracted FAQ texts to the collection
for idx, faq_text in enumerate(faq_texts):
    # Generate a unique ID for each document
    doc_id = f"faq_{idx}"
    
    # Generate embeddings for the FAQ text
    faq_embedding = embeddings.embed_query(faq_text.strip())
    
    # Add each text as a document to the collection
    faq_collection.upsert(documents=[faq_text.strip()], ids=[doc_id], embeddings=[faq_embedding])













