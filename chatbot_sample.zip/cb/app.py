from flask import Flask, request, jsonify, render_template
from sentence_transformers import SentenceTransformer
from chromadb import Client, Settings
from langchain_huggingface.llms import HuggingFaceEndpoint
from langchain.memory import ConversationBufferMemory
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.llms import CTransformers

app = Flask(__name__)

# Initialize Chroma client and SentenceTransformer
chroma_client = Client(Settings())
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load FAQ data and create ChromaDB collection
def load_faq_data(file_path):
    faq_data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read().strip()
        entries = content.split(' \n \n')
        for entry in entries:
            if entry.startswith('Q:') and '\nA:' in entry:
                question, answer = entry.split('\nA:', 1)
                question = question.replace('Q:', '').strip()
                answer = answer.strip()
                faq_data.append({'question': question, 'answer': answer})
    return faq_data

faq_data = load_faq_data('faq_texts.txt')

# Check if the collection exists, if not create it
collection_name = "faq_data"
existing_collections = chroma_client.list_collections()
if collection_name not in [col.name for col in existing_collections]:
    faq_collection = chroma_client.create_collection(collection_name)
    for faq in faq_data:
        embedding = model.encode(faq['question']).tolist()  # Encode the question to get embedding
        faq_collection.add(faq['question'], metadatas=[{'answer': faq['answer']}], embeddings=[embedding])
else:
    faq_collection = chroma_client.get_collection(collection_name)

# Initialize HuggingFaceHub LLM
llm = CTransformers(model="TheBloke/Llama-2-7B-Chat-GGML", model_file = 'llama-2-7b-chat.ggmlv3.q2_K.bin')
# Initialize memory for maintaining chat history
memory = ConversationBufferMemory()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    user_embedding = [float(x) for x in model.encode(user_message)]

    # Retrieve relevant FAQ entries
    search_results = faq_collection.query(user_embedding)

    top_answers = []
    relevant_info = ""
    threshold=0.5
    if search_results is not None and search_results.get("metadatas") is not None:
        metadatas = search_results["metadatas"][0]  # Extract metadatas 
        distances = search_results["distances"][0]  # Extract distances
        # Combine metadata and distances into tuples for sorting
        combined_data = zip(metadatas, distances)
         # Sort combined data based on distances
        sorted_data = sorted(combined_data, key=lambda x: x[1])
        for metadata, distance in sorted_data[:2]:
            if distance < threshold:
                top_answers.append(metadata["answer"])
        relevant_info = "\n".join(top_answers) if top_answers else ""

    # Prepare the combined input for the prompt
    history_text = ""
    if isinstance(memory.buffer, list) and len(memory.buffer) > 0:
        # Get only the last interaction
        last_interaction = memory.buffer[-1]
        history_text = f"{last_interaction.get('role', '')}: {last_interaction.get('content', '')}"

    combined_input = f"History:\n{history_text}\n\nFAQs:\n{relevant_info}\n\nUser's question: {user_message}"

    # Create a prompt template with a single input variable
    prompt_template = PromptTemplate(
        input_variables=["input"],
        template="Based only on the following information from the FAQs and slightly on previous conversation history, respond to the user's query in a concise way.\n\n{input}"
    )

    # Create the LangChain
    chain = LLMChain(llm=llm, prompt=prompt_template)

    input_data = {"input": combined_input}
    # Generate a response using LangChain
    response = chain.run(input_data)
    
    # Save the conversation to memory
    memory.save_context({"input": user_message}, {"output": response})
    print(response)
    print(combined_input)

    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)