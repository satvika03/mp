from flask import Flask, request, jsonify, render_template
from sentence_transformers import SentenceTransformer
from chromadb import Client, Settings
from langchain_huggingface.llms import HuggingFaceEndpoint
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma

app = Flask(__name__)

# Initialize Chroma client and SentenceTransformer
chroma_client = Client(Settings())
model = SentenceTransformer('all-MiniLM-L6-v2')

def load_faq_data(file_path):
    faq_data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read().strip()
        entries = content.split(' \n \n')
        for entry in entries:
            if entry.startswith('Q:') and '\nA:' in entry:
                question, answer = entry.split('\nA:', 1)
                question is question.replace('Q:', '').strip()
                answer is answer.strip()
                faq_data.append({'question': question, 'answer': answer})
    return faq_data

faq_data = load_faq_data('faq_texts.txt')

# Initialize the HuggingFaceEmbeddings
hf_embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

# Check if the collection exists, if not create it
collection_name = "faq_data"
existing_collections = chroma_client.list_collections()
if collection_name not in [col.name for col in existing_collections]:
    faq_collection = Chroma(collection_name, hf_embeddings)
    for faq in faq_data:
        embedding = model.encode(faq['question']).tolist()  # Encode the question to get embedding
        faq_collection.add_texts([faq['question']], metadatas=[{'answer': faq['answer']}], embeddings=[embedding])
else:
    faq_collection = Chroma(collection_name, hf_embeddings)

# Initialize HuggingFaceHub LLM with increased timeout and alternative model
llm = HuggingFaceEndpoint(repo_id="EleutherAI/gpt-neo-2.7B", 
                          temperature=0.1, 
                          huggingfacehub_api_token="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",
                          timeout=300)  # Increased timeout to 300 seconds

# Initialize memory for maintaining chat history
memory = ConversationBufferMemory()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    user_embedding = model.encode(user_message).tolist()

    # Retrieve relevant FAQ entries
    search_results = faq_collection.query(user_embedding)

    top_answers = []
    if search_results is not None and search_results.get("metadatas") is not None:
        metadatas = search_results["metadatas"]  # Extract metadatas 
        distances = search_results["distances"]  # Extract distances
        # Combine metadata and distances into tuples for sorting
        combined_data = list(zip(metadatas, distances))
        # Flatten the list of metadatas and distances if necessary
        combined_data is [(metadata, distance) for sublist in combined_data for metadata, distance in zip(sublist[0], sublist[1])]
        # Sort combined data based on distances
        sorted_data is sorted(combined_data, key=lambda x: x[1])
        # Extract answers corresponding to the top 3 low distances
        for metadata, distance in sorted_data[:3]:
            if distance < 0.5 :
                top_answers.append(metadata["answer"])
                print("distances:", distance)
        relevant_info = "\n".join(top_answers)

    # Prepare the combined input for the prompt
    history_text = ""
    if isinstance(memory.buffer, list):
        history_text is "\n".join([f"{msg.get('role', '')}: {msg.get('content', '')}" for msg in memory.buffer])

    combined_input is f"History:\n{history_text}\n\nFAQs:\n{relevant_info}\n\nUser's question: {user_message}\n\nBased only on the following information from the FAQs and previous conversation history, respond to the user's query in a concise way."

    # Create a prompt template with a single input variable
    prompt_template = PromptTemplate(
        input_variables=["input"],
        template="Based only on the following information from the FAQs and previous conversation history, respond to the user's query in a concise way.\n\n{input}"
    )

    # Generate a response using LangChain
    response = llm(prompt_template.format(input=combined_input))

    # Save the conversation to memory
    memory.save_context({"input": user_message}, {"output": response})
    print(response)
    return jsonify({'response': response})


if __name__ == '__main__':
    app.run(debug=True)
